#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include <ctype.h>

main() {
	int NumSys1, NumSys2, posl, dot, kz, rz, en, p, lc;
	long long a = 0;
	double b = 0.0;
	char hex[16] = { '0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F' };
	char Num[27];
	char Res[67];
	bool check = true;
	dot = 0;
	for (int k = 0; k < 27; k++)
		Num[k] = '!';
	scanf("%d", &NumSys1);
	scanf("%d", &NumSys2);
	scanf("%s", &Num);
	if ((NumSys1 > 16) || (NumSys1 < 2) || (NumSys2 > 16) || (NumSys2 < 2)) check = false;
	if (check) {
		for (int i = 0; i < 26; i++) {
			Num[i] = toupper(Num[i]);
			if ((Num[i] > hex[NumSys1 - 1])) {
				check = false;
			}
		}
	}
	int i = 0;
	while ((Num[i] != '.') && (Num[i] != '!')) {
		i++;
	}
	i = i - 1;
	lc = i;
	for (int e = 0; e < 26; e++) {
		if (Num[e] == '.') {
			dot++;
		}
		if (Num[e] == '!') {
			kz = e; break;
		}
	}
	if ((dot > 1) || (Num[0] == '.')) {
		check = false;
	}
	if (Num[kz - 2] == '.') {
		check = false;
	}
	if (check == true) {
		for (int j = 0; j < 67; j++) {
			Res[j] = '!';
		}
		if (dot == 0) {
			i--;
			lc--;
		}
		for (i; i >= 0; i--) {
			if ((int)(Num[lc - i]) > 57) {
				rz = 55;
			}
			else {
				rz = 48;
			}
			a = (a + ((int)(Num[lc - i]) - rz))*NumSys1;
		}
		a = a / NumSys1;
		lc = lc + 2;
		for (i = 0; i < 27; i++) {
			if (Num[i] == '!') {
				en = i;
				break;
			}
		}
		for (en; en > lc + 1; en--) {
			if ((int)(Num[en - 2] > 57)) {
				rz = 55;
			}
			else {
				rz = 48;
			}
			b = ((b + (int)(Num[en - 2]) - rz)) / NumSys1;
		}
		i = 53;
		Res[i + 1] = '.';
		Res[i] = '0';
		Res[i + 2] = '0';
		while (a > 0) {
			if (a%NumSys2 > 9) {
				rz = 55;
			}
			else {
				rz = 48;
			}
			Res[i] = a % NumSys2 + rz;
			i--;
			a = a / NumSys2;
		}
		p = 0;
		i = 55;
		if (b == 0.0) posl = 54; else posl = 67;
		while ((b > 0) && (p < 12)) {
			b = b * NumSys2;
			if ((int)(b) > 9) {
				rz = 55;
			}
			else {
				rz = 48;
			}
			Res[i] = (int)(b)+rz;
			i++;
			p++;
			if (b >= 1.0) {
				b = b - (int)(b);
			}
		}
		for (i = 0; i < posl; i++) {
			if (Res[i] != '!')
				printf("%c", Res[i]);
		}
	}
	else printf("bad input");
	return 0;
}