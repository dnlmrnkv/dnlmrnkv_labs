#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <malloc.h>

#define PAUSE 1

struct list;

struct stack {
	struct stack *next;
	int Num;
};

struct vertex {
	struct list *first;
	int Num;
	short int color;
};

struct list {
	struct list *next;
	struct vertex *ver;
};

void MakeList(struct list **list, struct vertex *ver) {
	struct list *elem = malloc(sizeof(struct list));
	elem->next = *list;
	elem->ver = ver;
	*list = elem;
}

void MakeStack(struct stack **stack, int Num) {
	struct stack *elem = malloc(sizeof(struct stack));
	elem->next = *stack;
	elem->Num = Num;
	*stack = elem;
}

void init(struct vertex *elem, int n) {
	for (int i = 0; i < n; i++) {
		elem[i].first = NULL;
		elem[i].color = 0;
		elem[i].Num = i;
	}
}

void die(struct vertex *t, int n) {
	for (int i = 0; i < n; i++) {
		while (t[i].first) {
			struct list *l = t[i].first;
			t[i].first = t[i].first->next;
			free(l);
		}
	}
	free(t);
	PAUSE;
}

int dfs(struct vertex *elem, struct stack **c) {
	if (elem->color == 1) {
		return -1;
	}
	elem->color = 1;
	while (elem->first) {
		struct list *help = elem->first;
		elem->first = elem->first->next;
		if (help->ver->color != 2 && dfs(help->ver, c) == -1) {
			free(help);
			return -1;
		}
		free(help);
	}
	MakeStack(c, elem->Num);
	elem->color = 2;
	return 0;
}

void Algorithm(struct vertex *graph, int n) {
	int check;
	struct stack *c = NULL;
	for (int i = 0; i < n; i++) {
		if (graph[i].color != 2) {
			check = dfs(&graph[i], &c);
			if (check == -1) {
				printf("impossible to sort");
				return;
			}
		}
	}
	while (c) {
		struct stack *h = c;
		c = c->next;
		printf("%d ", h->Num + 1);
	}
}

int main(void) {
	int n, m;
	struct vertex *graph;
	FILE *s = fopen("in.txt", "r");
	fscanf(s, "%d\n", &n);
	if (feof(s)) {
		printf("bad number of lines");
		fclose(s);
		PAUSE;
		return 0;
	}
	fscanf(s, "%d\n", &m);
	if (n < 0 || n>1000) {
		printf("bad number of vertices");
		fclose(s);
		PAUSE;
		return 0;
	}
	if (m<0 || m>n*(n - 1) / 2) {
		printf("bad number of edges");
		fclose(s);
		PAUSE;
		return 0;
	}
	graph = malloc(sizeof(struct vertex)*n);
	init(graph, n);
	for (int i = 0; i < m; i++) {
		int a, b;
		if (feof(s)) {
			printf("bad number of lines");
			fclose(s);
			die(graph, n);
			return 0;
		}
		fscanf(s, "%d %d", &a, &b);
		if (a<1 || a>n || b<1 || b>n) {
			printf("bad vertex");
			fclose(s);
			die(graph, n);
			return 0;
		}
		MakeList(&graph[a - 1].first, &graph[b - 1]);
	}
	Algorithm(graph, n);
	fclose(s);
	die(graph, n);
	return 0;
}