#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

void swap(char *a, char *b) {
	char c = *a;
	*a = *b;
	*b = c;
}

void sort(char *p, int f, int l) {
	bool sor = true;
	while (sor) {
		sor = false;
		for (int k = f; k < l; k++) {
			if (p[k] >= p[k + 1]) {
				swap(&p[k], &p[k + 1]);
				sor = true;
			}
		}
		l--;
	}
}

int main() {
	bool check = false;
	bool err = true;
	char p[10];
	int n;
	int i = 0;
	int zap;
	do {
		scanf("%c", &p[i++]);
	} while (p[i - 1] != '\n');
	scanf("%d", &n);
	if ((n == 0) || (i - 1 == 1)) return 0;
	i--;
	for (int k = 1; k < i; k++) {
		if (p[k] > p[k - 1])
			check = true;
		if ((p[k] != p[k - 1]))
			err = false;
		if ((p[k] < '0') || (p[k] > '9') || (p[0] < '0') || (p[0] > '9')) {
			err = true;
			break;
		}
	}
	if (err) {
		printf("bad input");
		return 0;
	}
	int min;
	if (check) {
		for (int q = 0; q < n; q++) {
			for (int k = i - 1; k > 0; k--) {
				if (p[k] > p[k - 1]) {
					zap = k - 1;
					min = zap + 1;
					for (int j = zap + 1; j < i; j++) {
						if ((p[min] > p[j]) && (p[j] > p[zap]))
							min = j;
					}
					swap(&p[min], &p[zap]);
					sort(p, zap + 1, i - 1);
					for (int j = 0; j < i; j++)
						printf("%c", p[j]);
					printf("\n");
					break;
				}
			}
		}
	}
	return 0;
}