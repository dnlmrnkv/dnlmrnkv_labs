#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <malloc.h>

void quickSort(int* mas, int first, int last) {
	int i = first, j = last, x = mas[(first + last) / 2];
	do {
		while (mas[i] < x) i++;
		while (mas[j] > x) j--;
		if (i <= j) {
			if (mas[i] > mas[j]) {
				int c = mas[i];
				mas[i] = mas[j];
				mas[j] = c;
			}
			i++;
			j--;
		}
	} while (i <= j);
	if (i < last)
		quickSort(mas, i, last);
	if (first < j)
		quickSort(mas, first, j);
}

int main() {
	int *a;
	int N;
	scanf("%d", &N);
	a = (int*)malloc(N * sizeof(int));
	for (int i = 0; i < N; i++) {
		scanf("%d", &a[i]);
	}
	quickSort(a, 0, N - 1);
	for (int i = 0; i < N; i++) {
		printf("%d ", a[i]);
	}
	return 0;
}