#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include <malloc.h>
#define TREE struct node

TREE {
	int height, data;
	TREE *left, *right;
};

int getHeight(TREE *elem) {
	if (elem == NULL) {
		return 0;
	}
	return elem->height;
}

TREE *create(int data, int i, TREE *a) {
	(&a[i])->data = data;
	(&a[i])->height = 1;
	(&a[i])->left = NULL;
	(&a[i])->right = NULL;
	return (&a[i]);
}

int max(int a, int b) {
	if (a > b) {
		return a;
	}
	return b;
}

void rotateR(TREE **elem) {
	TREE *p = *elem;
	TREE *h = (*elem)->right->left;
	(*elem) = (*elem)->right;
	p->right = h;
	(*elem)->left = p;
	(*elem)->left->height = max(getHeight((*elem)->left->left), getHeight((*elem)->left->right)) + 1;
	(*elem)->height = max(getHeight((*elem)->left), getHeight((*elem)->right)) + 1;
}

void rotateL(TREE **elem) {
	TREE *p = *elem;
	TREE *h = (*elem)->left->right;
	(*elem) = (*elem)->left;
	p->left = h;
	(*elem)->right = p;
	(*elem)->right->height = max(getHeight((*elem)->right->left), getHeight((*elem)->right->right)) + 1;
	(*elem)->height = max(getHeight((*elem)->left), getHeight((*elem)->right)) + 1;
}

void balance(TREE **elem) {
	if (getHeight((*elem)->left) - getHeight((*elem)->right) > 1) {
		if (getHeight((*elem)->left->right) > getHeight((*elem)->left->left)) {
			rotateR(&(*elem)->left);
		}
		TREE *p = *elem;
		TREE *h = (*elem)->left->right;
		(*elem) = (*elem)->left;
		p->left = h;
		(*elem)->right = p;
		(*elem)->right->height = max(getHeight((*elem)->right->left), getHeight((*elem)->right->right)) + 1;
		(*elem)->height = max(getHeight((*elem)->left), getHeight((*elem)->right)) + 1;
	}
	if (getHeight((*elem)->left) - getHeight((*elem)->right) < -1) {
		if (getHeight((*elem)->right->right) < getHeight((*elem)->right->left)) {
			rotateL(&(*elem)->right);
		}
		TREE *p = *elem;
		TREE *h = (*elem)->right->left;
		(*elem) = (*elem)->right;
		p->right = h;
		(*elem)->left = p;
		(*elem)->left->height = max(getHeight((*elem)->left->left), getHeight((*elem)->left->right)) + 1;
		(*elem)->height = max(getHeight((*elem)->left), getHeight((*elem)->right)) + 1;
	}

}

void pushLeaf(TREE **elem, int data, int i, TREE *a) {
	if (*elem == NULL) {
		*elem = create(data, i, a);
	} else {
		if (data > (*elem)->data) {
			pushLeaf(&(*elem)->right, data, i, a);
		} else {
			pushLeaf(&(*elem)->left, data, i, a);
		}
		(*elem)->height = max(getHeight((*elem)->left), getHeight((*elem)->right)) + 1;
		balance(elem);
	}
}

int main(void) {
	TREE *T = NULL, *a;
	int n;
	scanf("%d", &n);
	a = (TREE*)malloc(sizeof(TREE)*n);
	for (int i = 0; i < n; i++) {
		int data;
		scanf("%d", &data);
		pushLeaf(&T, data, i, a);
	}
	printf("%d", getHeight(T));
	return 0;
}