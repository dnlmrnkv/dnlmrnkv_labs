#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	unsigned char shabl[17];
	unsigned char str[40];
	int table[256] = { 0 };
	int poz = 1;
	int count;
	int len_shabl;
	int tri = 1;
	int sum_shabl = 0;
	int Num[32] = { 0 };
	int sum_str = 0;
	int k = 0;
	FILE *file = fopen("in.txt", "r");
	fgets(shabl, 18, file);
	len_shabl = strlen(shabl) - 1;
	for (int i = 0; i < len_shabl; i++) {
		int chisl = (shabl[i] % 3)*(tri);
		sum_shabl += chisl;
		tri *= 3;
	}
	printf("%d\n", sum_shabl);
	tri = 1;
	while (1) {
		int simb = fgetc(file);
		if (simb == EOF) {
			fclose(file);
			return 0;
		}
		else {
			if (k < len_shabl) {
				Num[k % (len_shabl)] = (simb);
				sum_str += ((unsigned char)Num[k % (len_shabl)] % 3)*(tri);
				tri *= 3;
				poz++;
			}
			else {
				int kd = Num[(k + len_shabl) % len_shabl];
				Num[k % (len_shabl)] = (simb);
				sum_str -= (((unsigned char)kd) % 3);
				sum_str = sum_str / 3;
				tri = tri / 3;
				sum_str += (((unsigned char)Num[k%len_shabl]) % 3)*(tri);;
				tri *= 3;
				poz++;
			}
			if (abs(sum_str - sum_shabl) < 1) {
				unsigned char check[17] = { 0 };
				count = poz;
				int j = 0;
				int p = 0;
				for (int z = k % len_shabl; z < len_shabl; z++) {
					check[p++] = (unsigned char)(Num[(z + 1) % len_shabl]);
				}
				for (int z = len_shabl; z < k%len_shabl + len_shabl; z++) {
					check[p++] = (unsigned char)(Num[(z + 1) % len_shabl]);
				}
				j = 0;
				if (count > len_shabl)
					for (int z = count - len_shabl; z < count; z++) {
						printf("%d ", z);
						if ((check[j]) != ((unsigned char)(shabl[j++]))) {
							break;
						}
					}
			}
		}
		k++;
	}
	return 0;
}