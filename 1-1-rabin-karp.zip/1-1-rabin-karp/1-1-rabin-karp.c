#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	unsigned char shablon[17];
	unsigned char string[40];
	int table[256] = { 0 };
	int pos = 1;
	int count;
	int len_shab;
	int tri = 1;
	int sum_shab = 0;
	int Num[32] = { 0 };
	int sum_str = 0;
	int k = 0;
	FILE *file = fopen("in.txt", "r");
	fgets(shablon, 18, file);
	len_shab = strlen(shablon) - 1;
	for (int i = 0; i < len_shab; i++) {
		int chisl = (shablon[i] % 3)*(tri);
		sum_shab += chisl;
		tri *= 3;
	}
	printf("%d\n", sum_shab);
	tri = 1;
	while (1) {
		int simb = fgetc(file);
		if (simb == EOF) {
			fclose(file);
			return 0;
		}
		else {
			if (k < len_shab) {
				Num[k % (len_shab)] = (simb);
				sum_str += ((unsigned char)Num[k % (len_shab)] % 3)*(tri);
				tri *= 3;
				pos++;
			}
			else {
				int kd = Num[(k + len_shab) % len_shab];
				Num[k % (len_shab)] = (simb);
				sum_str -= (((unsigned char)kd) % 3);
				sum_str = sum_str / 3;
				tri = tri / 3;
				sum_str += (((unsigned char)Num[k % len_shab]) % 3)*(tri);;
				tri *= 3;
				pos++;
			}
			if (abs(sum_str - sum_shab) < 1) {
				unsigned char check[17] = { 0 };
				count = pos;
				int j = 0;
				int p = 0;
				for (int z = k % len_shab; z < len_shab; z++) {
					check[p++] = (unsigned char)(Num[(z + 1) % len_shab]);
				}
				for (int z = len_shab; z < k % len_shab + len_shab; z++) {
					check[p++] = (unsigned char)(Num[(z + 1) % len_shab]);
				}
				j = 0;
				if (count > len_shab)
					for (int z = count - len_shab; z < count; z++) {
						printf("%d ", z);
						if ((check[j]) != ((unsigned char)(shablon[j++]))) {
							break;
						}
					}
			}
		}
		k++;
	}
	return 0;
}