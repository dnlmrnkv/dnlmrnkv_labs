#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

void sift(int *mas, int root, int bot) {
	int max;
	int prov = 0;
	while ((root * 2 <= bot) && (!prov)) {
		if (root * 2 == bot)
			max = root * 2;
		else if (mas[root * 2] > mas[root * 2 + 1])
			max = root * 2;
		else
			max = root * 2 + 1;
		if (mas[root] < mas[max]) {
			int c = mas[root];
			mas[root] = mas[max];
			mas[max] = c;
			root = max;
		}
		else
			prov = 1;
	}
}

void heapSort(int *mas, int size)
{
	for (int i = (size / 2); i >= 0; i--)
		sift(mas, i, size - 1);
	for (int i = size - 1; i >= 1; i--) {
		int c = mas[0];
		mas[0] = mas[i];
		mas[i] = c;
		sift(mas, 0, i - 1);
	}
}
int main() {
	int *a;
	int N;
	scanf("%d", &N);
	a = (int*)malloc(N * sizeof(int));
	for (int i = 0; i < N; i++)
		scanf("%d", &a[i]);
	heapSort(a, N);
	for (int i = 0; i < N; i++)
		printf("%d ", a[i]);
	printf("\n");
	return 0;
}
