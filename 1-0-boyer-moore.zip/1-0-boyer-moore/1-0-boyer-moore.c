#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
	unsigned char string[500] = { 0 };
	unsigned char shablon[32] = { 0 };
	unsigned char table[255] = { 0 };
	FILE *file = fopen("in.txt", "r");
	fgets(shablon, 20, file);
	int len_shab = strlen(shablon) - 1;
	shablon[len_shab] = '\0';
	int pos = len_shab - 1;
	for (int i = pos - 1; i >= 0; i--) {
		if (table[shablon[i]] == 0) {
			table[shablon[i]] = pos - i;
		}
	}
	for (int i = 0; i < 255; i++) {
		if (table[i] == 0) {
			table[i] = len_shab;
		}
	}
	for (int i = 0; i < len_shab; i++) {
		int simb = (fgetc(file));
		if (simb == EOF) {
			fclose(file);
			return 0;
		} else {
			string[i] = (unsigned char)(simb);
		}
	}
	while (1) {
		int move;
		for (int i = len_shab - 1; i >= 0; i--) {
			printf("%d ", pos - (len_shab - 1 - i) + 1);
			if (string[(pos - (len_shab - 1 - i)) % 32] != shablon[i]) {
				if (table[string[(pos - (len_shab - 1 - i)) % 32]] - (len_shab - 1 - i) > table[string[pos % 32]]) {
					move = table[string[(pos - (len_shab - 1 - i)) % 32]] - (len_shab - 1 - i);
					pos += move;
				} else {
					move = table[string[pos % 32]];
					pos += move;
				}
				break;
			} else {
				if (i == 0) {
					move = len_shab;
					pos += move;
				}
			}
		}
		for (int i = pos - move + 1; i < pos + 1; i++) {
			int simb = fgetc(file);
			if (simb == EOF) {
				fclose(file);
				return 0;
			} else {
				string[i % 32] = (unsigned char)(simb);
			}
		}
	}
	return 0;
}
